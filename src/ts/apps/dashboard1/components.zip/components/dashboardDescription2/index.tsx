
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import TypoGraphy from '@material-ui/core/Typography'
import TextField from '@material-ui/core/TextField';

import {
	changeDashboardId,
	changeDashboardName,
	changeDashboardDescription,
	//--
	initDashboardName,
	initDashboardDescription
} from '../../../../services/dashboard1/actions';

import { MuiThemeProvider } from '@material-ui/core';
import { themes } from '../../../../components/styles/themes';
import DashboardFavorite from '../dashboard-favorite';
import { IDashboardConfig, IDashboardConfigCollection } from '../../../../services/store/DashboardConfig';
import { IEditingDashboards } from '../../../../services/store/EditingDashboards';

import { startDashboardEdit, endDashboardEdit } from '../../../../services/store/EditingDashboards'
import { updateDashboardDesc, updateDashboardTitle } from '../../../../services/store/DashboardConfig'

import _ from 'underscore'

interface IDashboardHeaderProp {
	editingDashboardIds: Array<String>
	thisDashboardId: string //must have id for this dashboard
	dashboardConfigs: Array<IDashboardConfig>
	Actions: any

}

interface IDashboardHeaderState {
	DashboardConfig: IDashboardConfigCollection
	EditingDashboards: IEditingDashboards


}

class DashboardDescription2 extends React.Component<IDashboardHeaderProp, IDashboardHeaderState> {

	constructor(props: any) {
		super(props);

		// this.save = this.save.bind(this);
	}
	componentDidMount() {


		// this.props.thisDashboardConfig = GetCurrentDashboardConfig(this.props.thisDashboardId)

	}
	componentDidUpdate(_prevPros: any) {

	}

	// changeTitle = () => (event: React.ChangeEvent<HTMLInputElement>) => {
	// 	this.setState({
	// 		titleText: event.target.value
	// 	})
	// }
	// changeDescription = () => (event: React.ChangeEvent<HTMLInputElement>) => {
	// 	this.setState({
	// 		descriptionText: event.target.value
	// 	})
	// }

	isDashboardEditing(): boolean {
		return this.props.editingDashboardIds && this.props.editingDashboardIds.indexOf(this.props.thisDashboardId) != -1
	}
	onEdit = (_event: any):void =>{
		this.props.Actions.startDashboardEdit(this.props.thisDashboardId);
	}

	onInputKeyPress = (event: any, fieldType: string):void=> {
		if (event.key === 'Enter') {
			console.log('enter press here! ')
			if(fieldType == "desc"){
				this.props.Actions.updateDashboardDesc(this.props.thisDashboardId,event.target.value)

			}else if (fieldType == "title"){
				this.props.Actions.updateDashboardTitle(this.props.thisDashboardId,event.target.value)
			}else{
				console.warn('unknown field type edited',fieldType)
			}
		}
		else if (event.key === 'Escape') {
			console.log('escape press here! ')
			this.props.Actions.endDashboardEdit(this.props.thisDashboardId)
		}
	}


	render_editing_header(_thisDashboardConfig: IDashboardConfig) {
		return (<div>i am editing</div>)
	}
	render_header(thisDashboardConfig: IDashboardConfig) {
		return (
			<div style={{ display: "flex" }}>
				<div style={{ margin: "30px", userSelect: "none", width: "50%" }}>
					<TypoGraphy variant="h4" component="h4" gutterBottom style={{ wordWrap: "break-word" }}
					>
						{this.render_title(thisDashboardConfig)}
						{/* {this.render_edit_title_icon(thisDashboardConfig)} */}
					</TypoGraphy>
					<TypoGraphy variant="h6" component="h6" gutterBottom color="textSecondary" style={{ wordWrap: "break-word" }}
					>
						{this.render_description(thisDashboardConfig)}
						{/* {this.render_edit_description_icon(thisDashboardConfig)} */}
					</TypoGraphy>

				</div>
				<div style={{ margin: "30px" }}>
					<div style={{ margin: "30px" }}>
						<DashboardFavorite dashboardId={this.props.thisDashboardId}></DashboardFavorite>
					</div>
				</div>
			</div>)
	}
	renderDashboard(thisDashboardConfig: IDashboardConfig) {
		return (
			<MuiThemeProvider theme={themes["light"]}>
				{thisDashboardConfig != null &&  this.render_header(thisDashboardConfig)}


			</MuiThemeProvider>
		)
	}
	render() {
		console.error('fix this component, dashboard config should never be null if id exist --> thisDashboardConfig:IDashboardConfig|undefined  ')
		let thisDashboardConfig: IDashboardConfig | undefined = GetDashboardConfig(this.props.dashboardConfigs, this.props.thisDashboardId)
		return (
			<React.Fragment>
				{thisDashboardConfig != null && this.renderDashboard(thisDashboardConfig)}
			</React.Fragment>
		)
	}

	render_title(thisDashboardConfig: IDashboardConfig) {
		if (this.isDashboardEditing()) {
			// input
			return (
				<TypoGraphy component="div" style={{ display: "flex" }} >
					<TextField
						id="outlined-name"
						label="DashboardName"
						value={thisDashboardConfig.name}
						margin="normal"
						variant="outlined"
						onKeyPress={(e) => this.onInputKeyPress(e, "title")}
						fullWidth
					/>
					<TypoGraphy component="div" style={{ display: "flex", flexDirection: "column" }}>
						<i className="fa fa-check-circle fa-lg"
							style={{ marginTop: "17px", marginLeft: "4px", color: "green", cursor: "pointer" }}
						></i>
						<i className="fa fa-close fa-lg"
							style={{ marginTop: "10px", marginLeft: "4px", color: "#a59b59", cursor: "pointer" }}
						></i>
					</TypoGraphy>
				</TypoGraphy>
			)

		} else {
			// Label
			return (<div onDoubleClick={this.onEdit}>{thisDashboardConfig.name}</div>);
		}
	}
	render_description(thisDashboardConfig: IDashboardConfig) {
		if (this.isDashboardEditing()) {
			return (
				<TypoGraphy component="div" style={{ display: "flex" }}>
					<TextField
						id="outlined-name"
						label="Description_Edit"
						value={thisDashboardConfig.description}
						margin="normal"
						variant="outlined"
						onKeyPress={(e) => this.onInputKeyPress(e, "desc")}

						multiline
						fullWidth
					/>
					<TypoGraphy component="div" style={{ display: "flex", flexDirection: "column" }}>
						<i className="fa fa-check-circle fa-lg"
							style={{ marginTop: "17px", marginLeft: "4px", color: "green", cursor: "pointer" }}
						></i>
						<i className="fa fa-close fa-lg"
							style={{ marginTop: "10px", marginLeft: "4px", color: "#a59b59", cursor: "pointer" }}
						></i>
					</TypoGraphy>
				</TypoGraphy>
			)
		} else {
			// Label
			return (<div onDoubleClick={this.onEdit}>{thisDashboardConfig.description}</div>);
		}
	}

	
	// saveTitle = () => {
	// 	if (this.state.titleText == "") return;
	// 	else {
	// 		this.setState({
	// 			Title: this.state.titleText,
	// 			EnableEditTitle: false,
	// 			TitleEditState: false,
	// 			EditTitleIconHover: false
	// 		});
	// 		this.props.Actions.changeDashboardName(this.state.titleText);
	// 		// this.props.Actions.changeTitle(this.state.titleText, this.props.DashboardNumber);
	// 	}
	// }
	// cancelTitle = () => {
	// 	this.setState({
	// 		EnableEditTitle: false,
	// 		TitleEditState: false,
	// 		EditTitleIconHover: false,
	// 		titleText: this.state.Title
	// 	})
	// }
	// saveDescription = () => {
	// 	if (this.state.titleText == "") return;
	// 	else {
	// 		this.setState({
	// 			Description: this.state.descriptionText,
	// 			EnableEditDescription: false,
	// 			DescriptionEditState: false,
	// 			EditDescriptionIconHover: false
	// 		});
	// 		this.props.Actions.changeDashboardDescription(this.state.descriptionText);
	// 		// this.props.Actions.changeDescription(this.state.descriptionText, this.props.DashboardNumber);
	// 	}
	// }
	// cancelDescription = () => {
	// 	this.setState({
	// 		EnableEditDescription: false,
	// 		DescriptionEditState: false,
	// 		EditDescriptionIconHover: false,
	// 		descriptionText: this.state.Description
	// 	})
	// }
	// render_edit_title_icon() {
	// 	if (this.state.EnableEditTitle == true && this.state.TitleEditState == false) {
	// 		if (this.state.EditTitleIconHover == true) {
	// 			return (
	// 				<i className="fa fa-edit" style={{ color: "#614a0e", marginLeft: "5px", marginTop: "3px", display: "inline", cursor: "pointer" }}
	// 					onMouseLeave={() => {
	// 						this.setState({
	// 							EditTitleIconHover: false
	// 						})
	// 					}}
	// 					onClick={() => {
	// 						this.setState({
	// 							TitleEditState: true
	// 						})
	// 					}}
	// 				></i>
	// 			)
	// 		} else {
	// 			return (
	// 				<i className="fa fa-edit" style={{ color: "#a59b59", marginLeft: "5px", marginTop: "3px", display: "inline" }}
	// 					onMouseEnter={() => {
	// 						this.setState({
	// 							EditTitleIconHover: true
	// 						})
	// 					}}
	// 				></i>
	// 			)
	// 		}

	// 	} else {
	// 		return null;
	// 	}
	// }
	// render_edit_description_icon() {
	// 	if (this.state.EnableEditDescription == true && this.state.DescriptionEditState == false) {
	// 		if (this.state.EditDescriptionIconHover == true) {
	// 			return (
	// 				<i className="fa fa-edit" style={{ color: "#614a0e", marginLeft: "5px", marginTop: "3px", display: "inline", cursor: "pointer" }}
	// 					onMouseLeave={() => {
	// 						this.setState({
	// 							EditDescriptionIconHover: false
	// 						})
	// 					}}
	// 					onClick={() => {
	// 						this.setState({
	// 							DescriptionEditState: true
	// 						})
	// 					}}
	// 				></i>
	// 			);
	// 		} else {
	// 			return (
	// 				<i className="fa fa-edit" style={{ color: "#a59b59", marginLeft: "5px", marginTop: "3px", display: "inline" }}
	// 					onMouseEnter={() => {
	// 						this.setState({
	// 							EditDescriptionIconHover: true
	// 						})
	// 					}}
	// 				></i>
	// 			);
	// 		}

	// 	} else {
	// 		return null;
	// 	}
	// }
	// componentDidUpdate(prevPros: any) {
	// 	let _name, _description;
	// 	if (prevPros.name != this.props.name || prevPros.description != this.props.description || prevPros.favorite != this.props.favorite) {
	// 		if (this.props.name == "") _name = this.state.Title;
	// 		else _name = this.props.name;

	// 		if (this.props.description == "") _description = this.state.Description;
	// 		else _description = this.props.description;
	// 		this.setState({
	// 			Title: _name,
	// 			titleText: _name,
	// 			Description: _description,
	// 			descriptionText: _description,
	// 			hoverStart: false,
	// 			firstrender: 1
	// 		})
	// 	}
	// }
	// starHover() {
	// 	this.setState({
	// 		hoverStart: true
	// 	})
	// }
	// starLeave() {
	// 	this.setState({
	// 		hoverStart: false
	// 	})
	// }


}
function GetDashboardConfig(dashboards: Array<IDashboardConfig>, dashboardId: string): IDashboardConfig | undefined {

	let result: IDashboardConfig | undefined = _.find(dashboards, { id: dashboardId })
	return result;
}
const mapStateToProps = (state: IDashboardHeaderState) => {
	return {
		editingDashboardIds: state.EditingDashboards.editingDashboardIds,
		dashboardConfigs: state.DashboardConfig.dashboards

	};
};

export default connect(mapStateToProps, dispatch => {
	return {
		Actions: bindActionCreators(
			{
				startDashboardEdit,
				endDashboardEdit,
				updateDashboardTitle,
				updateDashboardDesc,

				changeDashboardId,
				changeDashboardDescription,
				changeDashboardName,
				//init;
				initDashboardName,
				initDashboardDescription
			},
			dispatch
		)
	}
})(DashboardDescription2);

