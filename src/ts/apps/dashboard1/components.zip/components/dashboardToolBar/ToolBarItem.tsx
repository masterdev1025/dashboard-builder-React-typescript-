import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
// import { generateUUIDv4 } from "@bitjourney/uuid-v4";
//---import Material Ui components--
import ListItemText from '@material-ui/core/ListItemText';
import TypoGraphy from '@material-ui/core/Typography';

//--- import Actions----
import {undo, redo,  initGlobal} from '../../../../services/dashboard1/actions';
import {createNewDashboard} from '../../../../services/store/DashboardConfig'
import {showModal, hideModal} from '../modals/modalAction';
//----------------------
interface ToolBarItemState {
	hover: any;
};
class ToolBarItem extends React.Component<any,ToolBarItemState>{
	constructor(props:any)
	{
		super(props);
		this.state = {
			hover:false
		}
		this.checkSaveEnable = this.checkSaveEnable.bind(this);
		this.save = this.save.bind(this);
	}
	checkSaveEnable()
	{
		var flag = false;
		var isExist = false;
		for(var i = 0; i < this.props.dashboards.length; i++)
		{
			if( this.props.dashboards[i].id == this.props.id)
			{
				if(this.props.dashboards[i].name != this.props.name ||
				   this.props.dashboards[i].description != this.props.description ||
				   this.props.dashboards[i].layout != this.props.currentLayout ||
				   this.props.dashboards[i].favorite != this.props.favorite
				){
					flag = true;
					break;
				}
				isExist = true;
			}
		}
		if(isExist == false) flag = true;
		var savedState = localStorage.getItem("savedDashboard1State");
		if(savedState != null && savedState != "")
		{
			var savedStateArray = JSON.parse(savedState);
			if(savedStateArray.dashboards.length != this.props.dashboards.length || savedStateArray.tabs.length != this.props.tabs.length ) flag = true;
		}
		return flag;
	}
	save(){
		var SavedData = {
			"dashboards": new Array(),
			"tabs":new Array(),
			"favoriteDashboards":new Array(),
			"favoriteTabs":new Array()
		}
		var currentDashboardTemp = {
			"id":          this.props.id,
			"name":        this.props.name,
			"description": this.props.description,
			"layout":      this.props.currentLayout,
			"favorite":    this.props.favorite
		};
		if( this.props.dashboards.length > 0 ) // testing if current dashboard is exist in Redux Store.
		{
			var isExist = false; 
			for(var i = 0; i < this.props.dashboards.length; i++)
			{
				if( this.props.dashboards[i].id == this.props.id ) // if current is equal to saved one dashboard
				{
					SavedData.dashboards.push(currentDashboardTemp);
					if(this.props.favorite == true )
					{
						var isExsitInFavoriteList = false;
						for(var j = 0; j < this.props.favoriteDashboards.length; j++)
						{
							SavedData.favoriteDashboards.push(this.props.favoriteDashboards[j])
							if(this.props.favoriteDashboards[j] == this.props.id){
								isExsitInFavoriteList = true;
							} 
						}
						if( isExsitInFavoriteList == false )
						{
							SavedData.favoriteDashboards.push(this.props.id);
						}
					} else { // the case: current favorite is false, but added in favoriteDashboard list
						for(var j = 0; j < this.props.favoriteDashboards.length; j++)
						{
							if(this.props.favoriteDashboards[j] != this.props.id){
								SavedData.favoriteDashboards.push(this.props.favoriteDashboards[j])
							}
						}
					}
					isExist = true;
				} else {
					SavedData.dashboards.push(this.props.dashboards[i]);
				}
			}
			if(isExist == false)
			{
				SavedData.dashboards.push(currentDashboardTemp);
				SavedData.favoriteDashboards = this.props.favoriteDashboards;
				if(this.props.favorite == true) SavedData.favoriteDashboards.push(this.props.id);
			}
		} else {
			SavedData.dashboards.push(currentDashboardTemp);
			if(this.props.favorite == true) SavedData.favoriteDashboards.push(this.props.id);
		}
		localStorage.setItem( 'savedDashboard1State', JSON.stringify(SavedData) );
		this.props.toolAction.initGlobal(
			SavedData.dashboards,
			SavedData.tabs,
			SavedData.favoriteDashboards,
			SavedData.favoriteTabs
		);
	}
	onClickItem = (_actionName:any) => {
		if(_actionName == "undoAction")
		{
			if(this.props.pastState.length > 1)
			{
				this.props.undoRedoAction.undo();
			}
		}else if(_actionName == "redoAction")
		{
			if(this.props.futureState.length > 0)
			{
				this.props.undoRedoAction.redo();
			}
		}else if(_actionName == "saveAction"){
			this.save();
		}else if(_actionName == "createDashboardAction"){

			//creating new dashboard.. 
			//todo fix this, call show model

			this.props.toolAction.createNewDashboard()

			if(this.checkSaveEnable() == true && this.props.id != "" && this.props.id != null)
			{
				this.props.modalAction.showModal("SAVE_CONFIRM_MODAL", this);
			} 
			// else {
			// 	this.props.toolAction.changeDashboardId(generateUUIDv4());
			// }
		} else {

		}
	}
	render_color = (_label:any) =>{
		if(_label == "Undo")
		{
			if(this.props.pastState.length <= 1 || this.props.pastState[this.props.pastState.length -1].id != this.props.id)
			{
				return "#c5c0c0";
			}
		}else if(_label == "Redo")
		{
			if(this.props.futureState.length == 0)
			{
				return "#c5c0c0";
			}
		}else if(_label == "Save")
		{
			if( this.checkSaveEnable() == false )
			{
				return "#c5c0c0";
			}
		}else{

		}
		return "black";
	}
	render_hover_color = (_label:any) => {
		if(_label == "Undo")
		{
			if(this.props.pastState.length <= 1 || this.props.pastState[this.props.pastState.length -1].id != this.props.id)
			{
				return "#c5c0c0";
			}
		}else if(_label == "Redo")
		{
			if(this.props.futureState.length == 0)
			{
				return "#c5c0c0";
			}
		}else if(_label == "Save")
		{
			if(this.checkSaveEnable() == false)
			{
				return "#c5c0c0";
			}
		}else{
			return "#ffc400";
		}
		return "#ffc400";
	}
	render_hover_cursor = (_label:any) => {
		if(_label == "Undo")
		{
			if(this.props.pastState.length <= 1 || this.props.pastState[this.props.pastState.length -1].id != this.props.id)
			{
				return "not-allowed";
			}
		}else if(_label == "Redo")
		{
			if(this.props.futureState.length == 0)
			{
				return "not-allowed";
			}
		}else if(_label == "Save")
		{
			if( this.checkSaveEnable() == false )
			{
				return "not-allowed";
			}
		}else{

		}
		return "pointer";
	}
	render()
	{
		const { Label } = this.props; //toolbar item label from config : example "undo", "redo"
		if(this.state.hover == true)
		{
			return(
				<ListItemText  inset style = {{ paddingLeft:"25px"}}>
					<TypoGraphy onClick = {() => this.onClickItem(this.props.actionName)}
						style = {{
							cursor:this.render_hover_cursor(Label),
							userSelect:"none",
							color:this.render_hover_color(Label)	
						}}
						onMouseLeave = {()=>{
							this.setState({
								hover:false
							})
						}}
					>
						<i className = {this.props.iconName} style = {{marginRight:"5px"}}></i>{Label}
					</TypoGraphy>
				</ListItemText>
			)
		}else{
			return(
				<ListItemText inset style = {{ paddingLeft:"25px"}}>
					<TypoGraphy 
					    onClick = {() => this.onClickItem(this.props.iconName)}
						style = {{
							cursor:"pointer",
							userSelect:"none",
							color:this.render_color(Label)	
						}}
						onMouseEnter = {()=>{
							this.setState({
								hover: true
							})
						}}
					>
						<i className = {this.props.iconName} style = {{marginRight:"5px"}}></i>{Label}
					</TypoGraphy>
				</ListItemText>
			)
		}
	}
};

export default connect(
	(state:any) => {
		return{
			//Current State--
			pastState:     state.CurrentState.past,
			futureState:   state.CurrentState.future,
			id:            state.CurrentState.present.id,                 //Dashboard State
			name:          state.CurrentState.present.name,               //   --id
			description:   state.CurrentState.present.description,        //   --name
			currentLayout: state.CurrentState.present.Layout,             //   --description
			favorite:      state.CurrentState.present.favorite,           //   --layout( golden-layout )
			//Golbal State--
			dashboards:         state.GlobalState.dashboards,
			tabs:               state.GlobalState.tabs,
			favoriteDashboards: state.GlobalState.favoriteDashboards,
			favoriteTabs:       state.GlobalState.favoriteTabs
		}
	},
	dispatch => {
		return {
			undoRedoAction: bindActionCreators(
				{ undo, redo },
				dispatch
			),
			toolAction:bindActionCreators(
				{ createNewDashboard, initGlobal },
				dispatch
			),
			modalAction:bindActionCreators(
				{showModal, hideModal},
				dispatch
			)
		}
	}
)(ToolBarItem);