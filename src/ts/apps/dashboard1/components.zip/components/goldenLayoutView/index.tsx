import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { updateLayout} from '../../../../services/dashboard1/actions';
import Swal from 'sweetalert2';
import GoldenLayout from 'golden-layout';
// import DashboardDescription from '../dashboardDescription';
import { Button } from '@material-ui/core';
// let goldenLayout:any;
interface goldenState{
	currentGolden:any
};
let golden_Layout:any;
let mouseClickFlag:any = 0;
class GoldenLayoutView extends React.Component<any, goldenState>{
	layout:any;
	layout1:any;
	firstRender:any;
	constructor(props:any)
	{
		super(props);
		this.state = {
			currentGolden:null
		};
		this.displayGoldenLayout = this.displayGoldenLayout.bind(this);
		this.dragButton_rendor = this.dragButton_rendor.bind(this);
		this.MouseDown = this.MouseDown.bind(this);
		this.MouseUp = this.MouseUp.bind(this);
		window.addEventListener("resize", this.updateScreen);
		window.addEventListener("mousedown", this.MouseDown);
		window.addEventListener("mouseup", this.MouseUp);
		this.firstRender = 0;
	}
	MouseDown(){
		mouseClickFlag = 1;
	}
	MouseUp(){
		mouseClickFlag = 0;
	}
	wrapComponent(Component:any){
		class Wrapped extends React.Component<any,any>{
		  componentWillMount(){
		  }
		  render() {
			return (
				<Component {...this.props} />
			);
		  }
		}
		return Wrapped;
	}
	updateScreen(){
		if(golden_Layout)
		{
			golden_Layout.updateSize(window.innerWidth - 17, window.innerHeight - 223);
		}
	}
	componentWillUnmount(){
		window.removeEventListener("resize", this.updateScreen);
		window.removeEventListener("mousedown", this.updateScreen);
		window.removeEventListener("mouseup", this.updateScreen);
	}
	displayGoldenLayout = (configeState:any) => {
		this.layout.innerHTML = "";
		golden_Layout = new GoldenLayout(configeState,this.layout);
		golden_Layout.on( 'stackCreated', (stack:any) => {
			stack
				.header
				.controlsContainer
				.find( '.lm_close' ) //get the close icon
				.off( 'click' ) //unbind the current click handler
				.click(function(){
					//add your own
					Swal.fire({
						title: 'Are you sure?',
						text: "You won't delete this layout?",
						type: 'warning',
						showCancelButton: true,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Yes, delete it!'
					  }).then((result) => {
						if (result.value) {
						  stack.remove();
						//   Swal.fire(
						// 	'Deleted!',
						// 	'That layout has been deleted.',
						// 	'success'
						//   )
						}
					  })
				});
		});
		golden_Layout.on( 'tabCreated', ( tab:any ) => {
			tab
				.closeElement
				.off( 'click' ) //unbind the current click handler
				.click(function(){
					console.log("sdfsdfsdfsdf");
					//add your own
					Swal.fire({
						title: 'Are you sure?',
						text: "You won't delete this tab?",
						type: 'warning',
						showCancelButton: true,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Yes, delete it!'
					  }).then((result) => {
						if (result.value) {
						  tab.contentItem.remove();
						//   Swal.fire(
						// 	'Deleted!',
						// 	'That tab has been deleted.',
						// 	'success'
						//   )
						}
					  })
				});
		});
		golden_Layout.on('stateChanged', ()=>{
			
			const currentLayout = this.props.currentLayout;
			const newLayout = JSON.stringify(golden_Layout.toConfig());
			if(currentLayout != newLayout && newLayout != "" && newLayout != null && currentLayout != null && currentLayout != "")
			{
				this.props.stateAction.updateLayout(newLayout);
			}
			this.updateScreen();
		});
		golden_Layout.registerComponent( 'DashboardDescription', function(){
		});
		golden_Layout.init();
		const drag_config = {
			title: "DRAG DROP",
			type: 'component',
			componentName: 'DashboardDescription'
		};
		this.dragButton_rendor(drag_config);
	}
	dragButton_rendor(config:any){
		this.layout1.innerHTML = config.title;
		golden_Layout.createDragSource( this.layout1, config );
	}
	componentDidMount(){
		if(this.firstRender == 0 && this.props.currentLayout != "")
		{
			this.displayGoldenLayout(JSON.parse(this.props.currentLayout));
			this.updateScreen();
			this.firstRender = 1;
		}
	}
	componentDidUpdate(prevProps:any)
	{
		if(this.firstRender == 0 && this.props.currentLayout != "")
		{
			this.displayGoldenLayout(JSON.parse(this.props.currentLayout));
			this.updateScreen();
			this.firstRender = 1;
		}
		if( prevProps.currentLayout != this.props.currentLayout && mouseClickFlag == 0 && this.props.currentLayout != "" && this.props.currentLayout != null && golden_Layout != null && golden_Layout != "")
		{
			golden_Layout.destroy();
			this.layout.innerHTML = "";
			golden_Layout.config = JSON.parse(this.props.currentLayout);
			golden_Layout.init();
			// 
			const drag_config = {
				title: "DRAG DROP",
				type: 'component',
				componentName: 'DashboardDescription'
			};
			this.dragButton_rendor(drag_config);
			this.updateScreen();
		}
	}

	render(){
		return(
			<div  style = {{width:"100%",flex: 1,display:"flex", flexDirection:"column"}}>
			  <div style = {{padding:"10px"}}>	<Button variant="contained" color="inherit" size="small" ref={(input1:any) => (this.layout1 = input1)} >NEW DASHBOARD</Button></div>
			  <div className="goldenLayout" ref={(input:any) => (this.layout = input)} style = {{flex:1}}/>
			</div>
		)
	}
}
export default connect(
	(state:any) => {
		return{
			currentLayout:state.CurrentState.present.Layout,
		}
	},
	dispatch => {
		return {
			stateAction: bindActionCreators(
				{ updateLayout },
				dispatch
			)
		}
	}
)(GoldenLayoutView);